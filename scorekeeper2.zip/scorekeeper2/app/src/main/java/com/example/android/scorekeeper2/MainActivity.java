package com.example.android.scorekeeper2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    int foulone = 0;
    int foultwo =0;
    int teama = 0;
    int teamb= 0;
   int setvalue =1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void displayteama()
    {
        TextView  displaysa = (TextView) findViewById(R.id.teamone);
        displaysa.setText(String.valueOf(teama));
    }
    public void displayteamb()
    {
        TextView displaysb = (TextView) findViewById(R.id.teamtwo);
        displaysb.setText(String.valueOf(teamb));
    }
    public void displayfoula()
    {
        TextView  displaya= (TextView) findViewById(R.id.foula);
        displaya.setText(String.valueOf(foulone));
    }
    public void displayfoulb()
    {
        TextView displayb = (TextView) findViewById(R.id.foulb);
        displayb.setText(String.valueOf(foultwo));
    }
    public void ta2points(View v)
    {teama = teama + 2;
        displayteama();
    }
    public void ta3points(View v)
    {
        teama = teama + 3;
        displayteama();
    }
    public void foula(View v)
    {
        foulone = foulone + 1;
        displayfoula();
    }
    public void foulb(View v)
    {
        foultwo = foultwo + 1;
        displayfoulb();
    }
    public void tb2points(View v)
    {
        teamb= teamb + 2;
        displayteamb();
    }
    public void tb3points(View v)
    {
        teamb= teamb + 3;
        displayteamb();
    }
      public void reset(View v)
    {
       teama=0;
       teamb=0;
       foulone =0;
       foultwo =0;
       displayteama();
       displayteamb();
       displayfoula();
       displayfoulb();
    }
      public void set(View v)
    {
       TextView sets = (TextView)findViewById(R.id.setshow);
       sets.setText(String.valueOf(setvalue));
       {
           sets.setText(String.valueOf(2));
           this.reset(v);
       }
    }
}